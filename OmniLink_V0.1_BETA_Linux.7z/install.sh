#!/bin/bash

echo "Installing OmniLink V0.1 BETA (Linux TUI)..."

# Check for Python 3
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed."
    exit 1
fi

# Define Install Paths
INSTALL_DIR="$HOME/.local/bin"
DATA_DIR="$HOME/.local/share/omnilink"
VENV_DIR="$DATA_DIR/venv"

mkdir -p "$INSTALL_DIR"
mkdir -p "$DATA_DIR"

# 1. Setup Virtual Environment (Fixes 'externally-managed-environment')
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment in $VENV_DIR..."
    python3 -m venv "$VENV_DIR"
fi

# 2. Install dependencies in venv
echo "Installing Python dependencies (rich)..."
"$VENV_DIR/bin/pip" install --upgrade pip
"$VENV_DIR/bin/pip" install rich

# 3. Copy Application File
# We copy the script to the local data directory so it runs independently of the source folder
SOURCE_SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/omnilink.py"
DEST_SCRIPT="$DATA_DIR/omnilink.py"

echo "Copying application to $DATA_DIR..."
cp "$SOURCE_SCRIPT" "$DEST_SCRIPT"

# 4. Create the wrapper script
echo "Creating 'omnilink' command in $INSTALL_DIR..."
cat << EOF > "$INSTALL_DIR/omnilink"
#!/bin/bash
"$VENV_DIR/bin/python3" "$DEST_SCRIPT" "\$@"
EOF

chmod +x "$INSTALL_DIR/omnilink"

# 5. Check Path
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo "Warning: $HOME/.local/bin is not in your PATH."
    echo "Add the following to your shell config (.bashrc, .zshrc, etc.):"
    echo "export PATH=\"\$HOME/.local/bin:\$PATH\""
fi

echo ""
echo "Installation complete!"
echo "The application is now installed locally in $DATA_DIR"
echo "You can run it by typing 'omnilink' in your terminal."
